package library.assistant.ui.callback;

/**
 * @author afsal
 */
public interface BookReturnCallback {
    public void loadBookReturn(String bookID);
}
